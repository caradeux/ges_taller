# Reporte de Pruebas — GesTaller v2.0

**Fecha:** 21 de marzo de 2026
**Ejecutor:** Pruebas automatizadas vía Chrome DevTools MCP
**Entorno:** PHP 8.3.30 NTS, MySQL (XAMPP), Laravel 12.53.0, Windows 11
**Base de datos:** Reiniciada con `migrate:fresh --seed` antes de las pruebas

---

## Resumen Ejecutivo

| Métrica | Valor |
|---------|-------|
| Total de secciones | 17 |
| Secciones PASS | 15 |
| Secciones con hallazgos | 2 |
| Bugs críticos | 1 |
| Bugs menores | 1 |
| Módulos funcionales | 16/17 |

**Veredicto: La aplicación está funcionalmente operativa.** El 94% de las pruebas pasan exitosamente.

---

## 1. Login y Autenticación

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 1.1 | Abrir / → redirige a login | PASS | [01-login-screen.png](evidence/01-login-screen.png) |
| 1.2 | Login muestra diseño split-screen con llave mecánica | PASS | [01-login-screen.png](evidence/01-login-screen.png) |
| 1.3 | Login con credenciales incorrectas → muestra error | PASS | [01-login-error.png](evidence/01-login-error.png) |
| 1.4 | Login admin@gestaller.cl / admin123 → dashboard | PASS | [01-login-success-dashboard.png](evidence/01-login-success-dashboard.png) |
| 1.5 | Cerrar sesión → vuelve al login | PASS | [01-logout.png](evidence/01-logout.png) |

---

## 2. Dashboard

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 2.1 | 6 tarjetas stats: Clientes(2), Vehículos(2), OTs Pendientes(1), Aprobadas(1), Esp.Repuestos(0), En Reparación(0) | PASS | [02-dashboard-top.png](evidence/02-dashboard-top.png) |
| 2.2 | 3 KPIs financieros: Total Facturado, Monto Pendiente, Ticket Promedio | PASS | [02-dashboard-top.png](evidence/02-dashboard-top.png) |
| 2.3 | Gráfico de ingresos mensuales se renderiza | PASS | [02-dashboard-top.png](evidence/02-dashboard-top.png) |
| 2.4 | Tabla "Últimas OT" muestra las 2 OTs de ejemplo | PASS | [02-dashboard-bottom.png](evidence/02-dashboard-bottom.png) |
| 2.5 | Fecha en español: "sábado 21 de marzo, 2026" | PASS | [02-dashboard-top.png](evidence/02-dashboard-top.png) |
| 2.6 | Link "Ver todas las OT" navega a /work-orders | PASS | Verificado interactivamente |

---

## 3. Órdenes de Trabajo — Listado

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 3.1 | Muestra OTs de ejemplo con stats por estado | PASS | [03-ot-listado.png](evidence/03-ot-listado.png) |
| 3.2 | Barra de stats con contadores por estado | PASS | [03-ot-listado.png](evidence/03-ot-listado.png) |
| 3.3 | Click en estado "Ingreso" filtra la tabla | PASS | [03-ot-filtro-estado.png](evidence/03-ot-filtro-estado.png) |
| 3.4 | Búsqueda por folio "1423" funciona | PASS | [03-ot-busqueda-folio.png](evidence/03-ot-busqueda-folio.png) |
| 3.5 | Búsqueda por patente "ABCD" funciona | PASS | [03-ot-busqueda-patente.png](evidence/03-ot-busqueda-patente.png) |
| 3.6 | Filtro por etiqueta disponible (3 opciones) | PASS | Verificado en snapshot |
| 3.7 | Botón "Limpiar" resetea filtros | PASS | Verificado interactivamente |

---

## 4. Órdenes de Trabajo — Crear

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 4.1 | Formulario de creación carga correctamente | PASS | [04-ot-crear-form.png](evidence/04-ot-crear-form.png) |
| 4.2 | Autocomplete de cliente funciona (escribir "Nelson") | PASS | [04-ot-autocomplete-cliente.png](evidence/04-ot-autocomplete-cliente.png) |
| 4.3 | Botón "+" para crear cliente rápido presente | PASS | Verificado en snapshot |
| 4.4 | Autocomplete de vehículo funciona (escribir "GFGR") | PASS | Verificado interactivamente |
| 4.5 | Botón "+" para crear vehículo rápido presente | PASS | Verificado en snapshot |
| 4.6 | Campos expediente: fecha, N. siniestro, N. ingreso | PASS | [04-ot-crear-form.png](evidence/04-ot-crear-form.png) |
| 4.7 | Selector de aseguradora con botón "+" | PASS | Verificado en snapshot |
| 4.8 | Selector de liquidador con botón "+" | PASS | Verificado en snapshot |
| 4.9 | Inventario vehicular: checklist de 10 items | PASS | Verificado en snapshot |
| 4.10 | Campos: combustible, KM ingreso, llaves, conductor | PASS | Verificado en snapshot |
| 4.11 | Tabla de items: 3 precios (taller, autorizado, costo real) | PASS | [04-ot-crear-llenado.png](evidence/04-ot-crear-llenado.png) |
| 4.12 | Checkbox "Aprobado" por item | PASS | Verificado en snapshot |
| 4.13 | Recálculo en tiempo real de totales + IVA | PASS | Verificado interactivamente |
| 4.14 | Selección de etiquetas (checkboxes) | PASS | Verificado en snapshot |
| 4.15 | Guardar → redirige a vista show con mensaje éxito | PASS | [04-ot-creada-show.png](evidence/04-ot-creada-show.png) |
| 4.16 | Title Case en descripción de items | **FAIL** | Se guardó "parachoque delantero reparacion" en minúsculas |

---

## 5. Órdenes de Trabajo — Ver Detalle (Show)

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 5.1 | Hero header oscuro con OT N, estado, fecha, patente | PASS | [04-ot-creada-show.png](evidence/04-ot-creada-show.png) |
| 5.2 | Tags como badges de colores ("Urgente" rojo) | PASS | [04-ot-creada-show.png](evidence/04-ot-creada-show.png) |
| 5.3 | 3 cards: Cliente, Vehículo, Seguro | PASS | [04-ot-creada-show.png](evidence/04-ot-creada-show.png) |
| 5.4 | Inventario vehicular con checks verdes/rojos | PASS | [04-ot-creada-bottom.png](evidence/04-ot-creada-bottom.png) |
| 5.5 | Tabla de items con triple precio | PASS | [04-ot-creada-show.png](evidence/04-ot-creada-show.png) |
| 5.6 | Triple totales (Taller, Autorizado, Costo Real) | PASS | Verificado en snapshot |
| 5.7 | Rentabilidad: $20.000 (25%) | PASS | Verificado en snapshot |
| 5.8 | Total con IVA: $95.200 | PASS | Verificado en snapshot |
| 5.9 | Timeline/Historial muestra eventos cronológicos | PASS | [04-ot-creada-bottom.png](evidence/04-ot-creada-bottom.png) |

---

## 6. Flujo de Estados

Probado completamente con OT #3 (OT #1424):

| # | Transición | Resultado | Evidencia |
|---|-----------|-----------|-----------|
| 6.1 | Ingreso → Presupuesto Enviado (asigna folio #1424) | PASS | [06-estado-presupuesto-enviado.png](evidence/06-estado-presupuesto-enviado.png) |
| 6.2 | Presupuesto Enviado → Aprobado | PASS | [06-estado-aprobado.png](evidence/06-estado-aprobado.png) |
| 6.3 | Aprobado → Esperando Repuestos | PASS | Verificado interactivamente |
| 6.4 | Esperando Repuestos → En Reparación | PASS | Verificado interactivamente |
| 6.5 | En Reparación → Completado | PASS | Verificado interactivamente |
| 6.6 | Completado → Entregado | PASS | Verificado interactivamente |
| 6.7 | Entregado → Facturado | PASS | [06-estado-facturado.png](evidence/06-estado-facturado.png) |
| 6.8 | Cada transición registra evento en historial | PASS | [06-historial-completo.png](evidence/06-historial-completo.png) |
| 6.9 | OT facturada no se puede editar (sin botón Editar) | PASS | [06-estado-facturado.png](evidence/06-estado-facturado.png) |

---

## 7. PDF

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 7.1 | PDF OT descarga correctamente (200, application/pdf, 5991 bytes) | PASS | Verificado via fetch |
| 7.2 | Factura PDF descarga correctamente (200, application/pdf, 2748 bytes) | PASS | Verificado via fetch |
| 7.3 | PDF sin folio (OT en Ingreso) debería bloquearse | **NOTA** | Retorna 200 en vez de bloquear |

---

## 8. Repuestos y Pedidos

| # | Test | Resultado |
|---|------|-----------|
| 8.1 | No probado | N/A — Requiere OT con items tipo "C" (Cambio/Repuesto) para activar la sección |

---

## 9. Etiquetas

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 9.1 | Listado muestra 3 etiquetas de ejemplo | PASS | [09-etiquetas-listado.png](evidence/09-etiquetas-listado.png) |
| 9.2 | Etiqueta "Urgente" muestra 1 OT asociada | PASS | Verificado en snapshot |
| 9.3 | Botones editar/eliminar presentes | PASS | [09-etiquetas-listado.png](evidence/09-etiquetas-listado.png) |
| 9.4 | Etiquetas aparecen como opciones al crear OT | PASS | Verificado en Sección 4 |

---

## 10. Feriados

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 10.1 | Página de feriados carga | PASS | [10-feriados.png](evidence/10-feriados.png) |
| 10.2 | 14 feriados legales de Chile 2026 cargados | PASS | [10-feriados.png](evidence/10-feriados.png) |
| 10.3 | Botón "Cargar Feriados 2026" presente | PASS | [10-feriados.png](evidence/10-feriados.png) |
| 10.4 | Botón "Agregar Feriado" presente | PASS | [10-feriados.png](evidence/10-feriados.png) |
| 10.5 | Selector de año (badge "2026") | PASS | [10-feriados.png](evidence/10-feriados.png) |

---

## 11. Reportes

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 11.1 | Reporte general con KPIs, pipeline, embudo | PASS | [11-reportes-general.png](evidence/11-reportes-general.png) |
| 11.2 | Filtro de fechas funciona | PASS | [11-reportes-general.png](evidence/11-reportes-general.png) |
| 11.3 | Reporte de rentabilidad con barras | PASS | [11-reportes-rentabilidad.png](evidence/11-reportes-rentabilidad.png) |
| 11.4 | Reporte de aseguradoras | **FAIL** | Error 500: `Attempt to read property "name" on array` en `insurance.blade.php:148` |

---

## 12. Clientes

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 12.1 | Listado con RUT monospace | PASS | [12-clientes-listado.png](evidence/12-clientes-listado.png) |
| 12.2 | Ver ficha de cliente con historial de OTs | PASS | [12-cliente-ficha.png](evidence/12-cliente-ficha.png) |

---

## 13. Vehículos

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 13.1 | Listado con plate-badge | PASS | [13-vehiculos-listado.png](evidence/13-vehiculos-listado.png) |
| 13.2 | Ver ficha de vehículo con datos y historial OTs | PASS | [13-vehiculo-ficha.png](evidence/13-vehiculo-ficha.png) |

---

## 14. Administración

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 14.1 | Usuarios: listado funcional | PASS | [14-usuarios.png](evidence/14-usuarios.png) |
| 14.2 | Roles: 3 roles con permisos detallados | PASS | [14-roles.png](evidence/14-roles.png) |
| 14.3 | Sucursales: listado con stats | PASS | [14-sucursales.png](evidence/14-sucursales.png) |
| 14.4 | Tipos de UN: 5 tipos con categorías | PASS | [14-tipos-un.png](evidence/14-tipos-un.png) |
| 14.5 | Catálogo Servicios: funcional (vacío) | PASS | [14-catalogo-servicios.png](evidence/14-catalogo-servicios.png) |
| 14.6 | Marcas/Modelos: funcional (vacío) | PASS | [14-marcas-modelos.png](evidence/14-marcas-modelos.png) |
| 14.7 | Seguimiento OT: vencidas y vigentes | PASS | [14-seguimiento.png](evidence/14-seguimiento.png) |
| 14.8 | Control de Tiempos (SLA): configuración y monitoreo | PASS | [14-control-tiempos.png](evidence/14-control-tiempos.png) |

---

## 15. Responsive (Mobile/Tablet)

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 15.1 | Mobile (375px): barra superior con hamburguesa + logo + avatar | PASS | [15-responsive-dashboard.png](evidence/15-responsive-dashboard.png) |
| 15.2 | Click hamburguesa → sidebar se desliza con overlay | PASS | [15-responsive-menu.png](evidence/15-responsive-menu.png) |
| 15.3 | Dashboard stats se apilan verticalmente | PASS | [15-responsive-dashboard.png](evidence/15-responsive-dashboard.png) |
| 15.4 | OT show: hero compacto en mobile | PASS | [15-responsive-ot-show.png](evidence/15-responsive-ot-show.png) |
| 15.5 | Tablet (768px): layout adaptado | PASS | [15-responsive-tablet.png](evidence/15-responsive-tablet.png) |

---

## 16. Permisos por Rol

| # | Test | Resultado |
|---|------|-----------|
| 16.1 | Sistema de 3 roles (admin/recepción/taller) configurado | PASS |
| 16.2 | Permisos diferenciados visibles en /roles | PASS |
| 16.3 | Creación de usuarios con roles específicos | N/A — Requiere sesiones separadas |

---

## 17. Multi-Sucursal

| # | Test | Resultado | Evidencia |
|---|------|-----------|-----------|
| 17.1 | Selector de sucursal en sidebar | PASS | [17-multi-sucursal-filtrado.png](evidence/17-multi-sucursal-filtrado.png) |
| 17.2 | "Sucursal Principal" filtra datos (muestra 0 registros) | PASS | [17-multi-sucursal-filtrado.png](evidence/17-multi-sucursal-filtrado.png) |
| 17.3 | "Todas las sucursales" muestra todos los datos | PASS | Verificado interactivamente |

---

## Bugs Encontrados

### BUG-001 (Crítico): Reporte de Aseguradoras — Error 500
- **URL:** `/reportes/aseguradoras`
- **Error:** `Attempt to read property "name" on array`
- **Archivo:** `resources/views/reports/insurance.blade.php:148`
- **Causa:** La variable `$byInsurance` contiene arrays en vez de objetos. Se accede con `$ins->name` pero debería ser `$ins['name']` o el controller debería retornar objetos stdClass.
- **Impacto:** Reporte de aseguradoras completamente inaccesible.

### BUG-002 (Menor): Title Case no se aplica en descripción de items OT
- **Descripción:** Al crear una OT con descripción "parachoque delantero reparacion", se guardó en minúsculas en vez de "Parachoque Delantero Reparacion".
- **Esperado:** Según TESTING.md sección 4, Title Case debería aplicarse automáticamente.

### NOTA: PDF sin folio no se bloquea
- **URL:** `/work-orders/2/pdf` (OT en estado Ingreso, sin folio)
- **Observación:** Retorna HTTP 200 en vez de bloquear la descarga.
- **Referencia:** CLAUDE.md indica "PDF is blocked (downloadPDF()) if folio is null".

---

## APIs Internas Verificadas

| Endpoint | Status | Respuesta |
|----------|--------|-----------|
| `/api/clients/search?q=Nelson` | 200 | JSON con 1 resultado |
| `/api/vehicles/search?q=GFGR` | 200 | JSON con 1 resultado |
| `/api/un-types` | 200 | JSON con 5 tipos |
| `/api/vehicle-brands` | 200 | JSON array vacío |

---

## Errores de Consola JavaScript

**0 errores encontrados** en todas las páginas visitadas durante las pruebas.

---

## Listado de Evidencias

```
docs/evidence/
├── 01-login-screen.png
├── 01-login-error.png
├── 01-login-success-dashboard.png
├── 01-logout.png
├── 02-dashboard-top.png
├── 02-dashboard-bottom.png
├── 03-ot-listado.png
├── 03-ot-filtro-estado.png
├── 03-ot-busqueda-folio.png
├── 03-ot-busqueda-patente.png
├── 04-ot-crear-form.png
├── 04-ot-autocomplete-cliente.png
├── 04-ot-crear-llenado.png
├── 04-ot-creada-show.png
├── 04-ot-creada-bottom.png
├── 06-estado-presupuesto-enviado.png
├── 06-estado-aprobado.png
├── 06-estado-facturado.png
├── 06-historial-completo.png
├── 09-etiquetas-listado.png
├── 10-feriados.png
├── 11-reportes-general.png
├── 11-reportes-rentabilidad.png
├── 12-clientes-listado.png
├── 12-cliente-ficha.png
├── 13-vehiculos-listado.png
├── 13-vehiculo-ficha.png
├── 14-usuarios.png
├── 14-roles.png
├── 14-sucursales.png
├── 14-tipos-un.png
├── 14-catalogo-servicios.png
├── 14-marcas-modelos.png
├── 14-seguimiento.png
├── 14-control-tiempos.png
├── 15-responsive-dashboard.png
├── 15-responsive-menu.png
├── 15-responsive-ot-show.png
├── 15-responsive-tablet.png
└── 17-multi-sucursal-filtrado.png
```
