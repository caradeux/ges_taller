# Manual de Usuario — GesTaller v2.0

Sistema de Gestión de Taller Automotriz

---

## 1. Acceso al Sistema

### Iniciar Sesión

Al abrir la aplicación, se muestra la pantalla de login con diseño split-screen.

![Pantalla de Login](evidence/01-login-screen.png)

1. Ingrese su **correo electrónico** en el campo correspondiente
2. Ingrese su **contraseña**
3. Opcionalmente marque **"Recordarme"** para mantener la sesión
4. Haga click en **"Iniciar Sesión"**

Si las credenciales son incorrectas, se mostrará un mensaje de error:

![Error de Login](evidence/01-login-error.png)

### Cerrar Sesión

Haga click en el botón **"Cerrar Sesión"** ubicado al final del menú lateral izquierdo.

---

## 2. Panel General (Dashboard)

Al ingresar, verá el panel general con un resumen operativo del taller.

![Dashboard](evidence/02-dashboard-top.png)

### Elementos del Dashboard

- **6 Tarjetas de estadísticas:** Clientes, Vehículos, OTs Pendientes, OTs Aprobadas, Esperando Repuestos, En Reparación
- **3 KPIs financieros:** Total Facturado (CLP), Monto Pendiente, Ticket Promedio
- **Gráfico de Ingresos Mensuales:** Muestra la facturación de los últimos 6 meses
- **Tabla "Últimas Órdenes de Trabajo":** Las 5 OTs más recientes con folio, cliente, vehículo, fecha, estado y total
- **Fecha actual** en español (ej: "sábado 21 de marzo, 2026")

![Dashboard - Tabla OTs](evidence/02-dashboard-bottom.png)

---

## 3. Órdenes de Trabajo

### 3.1 Listado de OTs

Acceda desde el menú lateral **"Órdenes de Trabajo"**.

![Listado OTs](evidence/03-ot-listado.png)

#### Barra de Estados
En la parte superior se muestran contadores por estado. Haga click en cualquier estado para filtrar la tabla:

![Filtro por Estado](evidence/03-ot-filtro-estado.png)

#### Búsqueda
Use el campo de búsqueda para buscar por:
- **Folio** (ej: "1423")
- **Nombre del cliente** (ej: "Nelson")
- **Patente** (ej: "GFGR")
- **Aseguradora**

![Búsqueda por Folio](evidence/03-ot-busqueda-folio.png)

#### Filtro por Etiqueta
Use el selector de etiquetas para filtrar OTs por etiqueta (Urgente, Pendiente de Repuesto, etc.)

#### Limpiar Filtros
Haga click en el ícono de "limpiar" junto al botón Filtrar para resetear todos los filtros.

### 3.2 Crear Nueva OT

Haga click en **"+ Nueva OT"** desde el listado o el dashboard.

![Formulario Nueva OT](evidence/04-ot-crear-form.png)

#### Datos del Expediente
1. **Cliente:** Escriba el nombre o RUT para buscar. Se mostrará un autocompletado.
   ![Autocomplete Cliente](evidence/04-ot-autocomplete-cliente.png)
   - Use el botón **"+"** para crear un cliente nuevo desde un modal rápido.
2. **Vehículo:** Escriba la patente, marca o modelo para buscar.
   - Use el botón **"+"** para crear un vehículo nuevo.
3. **Fecha:** Se carga automáticamente con la fecha actual.
4. **N. Siniestro / N. Ingreso:** Campos opcionales para expedientes de seguros.

#### Seguro y Liquidación
- Seleccione la **Compañía Aseguradora** (o "Sin seguro" para particulares)
- Seleccione el **Liquidador** asignado
- Ingrese el **Deducible** en CLP si aplica

#### Inventario de Ingreso
Marque los items que el vehículo trae al ingresar:
- Rueda de Repuesto, Grúa, Gata, Kit de Seguridad, Panel de Radio, Pisos de Goma, Antena, Logos, TAG/Telepeaje, Objetos de Valor
- Seleccione el nivel de **Combustible** (Vacío, 1/4, 1/2, 3/4, Lleno)
- Ingrese **KM de ingreso** y cantidad de **Llaves**
- Complete **Conductor** y **Declaración de objetos**

#### Detalle de Trabajos
![Formulario con Items](evidence/04-ot-crear-llenado.png)

Para cada línea de trabajo:
1. Seleccione el **Tipo UN** (REP, PINT, D/M, C, MAT)
2. Escriba la **Descripción** del trabajo
3. Ingrese los 3 montos: **Monto Taller**, **Monto Autorizado**, **Costo Real**
4. Marque **Aprobado** si el item está aprobado
5. Marque **Salvar** si es salvage
6. Use **"+ Agregar línea"** para más items

Los totales se calculan automáticamente en tiempo real (Neto + IVA 19%).

#### Etiquetas
Marque las etiquetas que apliquen (Urgente, Pendiente de Repuesto, Re-inspección).

#### Guardar
Click en **"Guardar OT"**. Se redirigirá a la vista detalle con mensaje de éxito.

### 3.3 Ver Detalle de OT

![Detalle OT](evidence/04-ot-creada-show.png)

La vista detalle muestra:
- **Hero header oscuro** con número de OT, estado, fecha y vehículo
- **Etiquetas** como badges de colores
- **3 Cards:** Datos del Cliente, Vehículo y Seguro/Siniestro
- **Inventario Vehicular** con checks verdes (presente) y rojos (ausente)
- **Tabla de Items** con triple precio y checkbox de aprobación
- **Totales:** Neto Taller, Neto Autorizado, Costo Real
- **Rentabilidad:** Ganancia y margen porcentual
- **Total a Cobrar** con IVA 19%
- **Historial/Timeline** con todos los eventos cronológicos

![Detalle OT - Bottom](evidence/04-ot-creada-bottom.png)

---

## 4. Flujo de Estados de una OT

Cada OT sigue un flujo de 8 estados. Los botones de acción disponibles cambian según el estado actual.

| Estado | Acción Siguiente | Descripción |
|--------|-----------------|-------------|
| **Ingreso** | Enviar Presupuesto | OT recién creada, sin folio |
| **Presupuesto Enviado** | Aprobar | Se asigna folio automático, se habilita PDF |
| **Aprobado** | Esp. Repuestos / Iniciar Reparación | Cliente aprobó el presupuesto |
| **Esperando Repuestos** | Iniciar Reparación | En espera de piezas |
| **En Reparación** | Completar | Trabajo en progreso |
| **Completado** | Entregar | Trabajo terminado |
| **Entregado** | Facturar | Vehículo entregado al cliente |
| **Facturado** | — | Estado final, OT no editable |

![Estado Presupuesto Enviado](evidence/06-estado-presupuesto-enviado.png)

![Estado Aprobado](evidence/06-estado-aprobado.png)

![Estado Facturado](evidence/06-estado-facturado.png)

Cada transición se registra automáticamente en el historial:

![Historial Completo](evidence/06-historial-completo.png)

---

## 5. PDF

Desde una OT con folio asignado (estado Presupuesto Enviado o posterior):

- **PDF OT:** Documento completo con datos del cliente, vehículo, items, inventario y firmas
- **Factura:** Documento limpio con totales para el cliente

---

## 6. Módulos de Gestión

### Clientes
![Listado Clientes](evidence/12-clientes-listado.png)

Gestione clientes con RUT, nombre, email, teléfono y vehículos asociados.

![Ficha Cliente](evidence/12-cliente-ficha.png)

### Vehículos
![Listado Vehículos](evidence/13-vehiculos-listado.png)

Gestione vehículos con patente, marca/modelo, año, propietario y odómetro.

![Ficha Vehículo](evidence/13-vehiculo-ficha.png)

### Aseguradoras y Liquidadores

Gestione las compañías de seguros y sus liquidadores asignados desde los menús correspondientes.

---

## 7. Seguimiento y Control de Tiempos

### Seguimiento de OTs
![Seguimiento](evidence/14-seguimiento.png)

Muestra las OTs activas organizadas por urgencia:
- **Vencidas:** OTs que superaron la vigencia configurada (en rojo)
- **Vigentes:** OTs dentro del plazo, con días restantes

### Control de Tiempos (SLA)
![Control de Tiempos](evidence/14-control-tiempos.png)

Configure los tiempos máximos (días hábiles) por etapa y monitoree las OTs que los exceden.

---

## 8. Reportes

### Reporte General
![Reportes](evidence/11-reportes-general.png)

Incluye:
- Resumen ejecutivo con KPIs
- Pipeline de OTs por estado
- Distribución por aseguradora
- Top clientes

### Reporte de Rentabilidad
![Rentabilidad](evidence/11-reportes-rentabilidad.png)

Análisis de ganancia por OT con:
- Indicadores clave (Total Autorizado, Costo Real, Ganancia, Margen %)
- Gráfico de barras por OT
- Detalle por orden

---

## 9. Administración

### Usuarios
![Usuarios](evidence/14-usuarios.png)

Gestione usuarios del sistema: crear, editar, activar/desactivar, asignar roles y sucursales.

### Roles y Permisos
![Roles](evidence/14-roles.png)

Tres roles del sistema:
- **Administrador:** Acceso completo
- **Recepción:** Crear/editar OTs, clientes, vehículos. Sin eliminar ni administrar.
- **Taller:** Solo lectura de OTs, clientes y vehículos.

### Sucursales
![Sucursales](evidence/14-sucursales.png)

Gestione las ubicaciones del taller. Cada sucursal tiene sus propios datos de clientes, vehículos y OTs.

### Etiquetas
![Etiquetas](evidence/09-etiquetas-listado.png)

Cree etiquetas con nombre y color para clasificar las OTs (ej: Urgente, Pendiente de Repuesto).

### Feriados
![Feriados](evidence/10-feriados.png)

Calendario de feriados legales de Chile para cálculo de días hábiles. Puede cargar los feriados del año o agregar manualmente.

### Catálogos
- **Tipos de UN:** Categorías para los items de trabajo (Reparación, Pintura, D/M, Cambio, Material)
  ![Tipos UN](evidence/14-tipos-un.png)
- **Catálogo Servicios:** Items frecuentes con precios base para autocompletar
- **Marcas/Modelos:** Catálogo de vehículos para normalizar datos

---

## 10. Multi-Sucursal

El administrador puede filtrar datos por sucursal usando el selector en el sidebar:

![Multi-Sucursal](evidence/17-multi-sucursal-filtrado.png)

- **"Todas las sucursales":** Muestra datos de todas las ubicaciones
- **Sucursal específica:** Filtra clientes, vehículos y OTs de esa sucursal

---

## 11. Vista Responsive (Móvil)

La aplicación se adapta automáticamente a dispositivos móviles y tablets.

### Móvil (375px)
![Dashboard Móvil](evidence/15-responsive-dashboard.png)

- Barra superior con menú hamburguesa, logo y avatar
- Stats apilados verticalmente

![Menú Móvil](evidence/15-responsive-menu.png)

- Sidebar se desliza desde la izquierda con overlay

![OT Show Móvil](evidence/15-responsive-ot-show.png)

### Tablet (768px)
![Dashboard Tablet](evidence/15-responsive-tablet.png)

---

## Credenciales de Acceso

| Rol | Email | Contraseña |
|-----|-------|------------|
| Administrador | admin@gestaller.cl | admin123 |
